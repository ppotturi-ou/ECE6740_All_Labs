/*
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A 
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR 
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION 
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE 
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO 
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO 
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE 
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 */

/*
 * 
 *
 * This file is a generated sample test application.
 *
 * This application is intended to test and/or illustrate some 
 * functionality of your system.  The contents of this file may
 * vary depending on the IP in your system and may use existing
 * IP driver functions.  These drivers will be generated in your
 * SDK application project when you run the "Generate Libraries" menu item.
 *
 */

#include <stdio.h>
#include "xparameters.h"
#include "xil_cache.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "scugic_header.h"
#include "xdevcfg.h"
#include "devcfg_header.h"
#include "xdmaps.h"
#include "dmaps_header.h"
#include "xqspips.h"
#include "qspips_header.h"
#include "xscutimer.h"
#include "scutimer_header.h"
#include "xscuwdt.h"
#include "scuwdt_header.h"


#include "xil_printf.h"
#include "sleep.h"
#include "stdbool.h"

#include "xscugic.h"
#include "xscutimer.h"
#include "xil_exception.h"

#define SEQ_DTCT_CUSTOM_IP_BASE_ADDR (XPAR_MYIP_SEQSQRT_0_S00_AXI_BASEADDR)
#define SEQ_DTCT_CUSTOM_IP_INTR_ID   (61U)

#define TIMER_DEVICE_ID				 (XPAR_XSCUTIMER_0_DEVICE_ID)
#define TIMER_INTR_ID			     (XPAR_SCUTIMER_INTR)

#define SCUTIMER_FREQ			     (333e6) // PL_Freq/2 (PL_Freq = 666.666Mhz)
#define TIMER_VALUE_SEC			 	 (1)
#define TIMER_LOAD_VALUE			 (SCUTIMER_FREQ*TIMER_VALUE_SEC)
#define ADDER_BASEADDERSS 			 XPAR_MYIP_SEQSQRT_0_S00_AXI_BASEADDR

unsigned int sqrt1=0,data_buffer,btn,done_stat;

XScuGic IntcInstancePtr;
XScuGic_Config *IntcConfig;

XScuTimer TimerInstance;
XScuTimer_Config *ConfigPtr;

XScuTimer *timerptr=NULL;

u16 mm=0,ss=0;

u32 ScuInit(){
	u32 Status;

	IntcConfig = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);
	if (NULL == IntcConfig) {
		xil_printf("LookupConfig Fail..\n\r");
		return XST_FAILURE;
	}
	Status = XScuGic_CfgInitialize(&IntcInstancePtr, IntcConfig,IntcConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS) {
		xil_printf("CfgInitialize Fail..\n\r");
		return XST_FAILURE;
	}

	xil_printf("ScuInit Successful!\r\n");
	return XST_SUCCESS;
}

u32 TimerInit(){
	u32 Status;

	/*
	 * Initialize the Timer driver.
	 */
	ConfigPtr = XScuTimer_LookupConfig(TIMER_DEVICE_ID);

	/*
	 * This is where the virtual address would be used, this example
	 * uses physical address.
	 */
	Status = XScuTimer_CfgInitialize(&TimerInstance, ConfigPtr,
					ConfigPtr->BaseAddr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	timerptr=&TimerInstance;
	xil_printf("TimerInit Successful!\r\n");
	return XST_SUCCESS;

}

u32 IntrCfg(u32 IntrId1,u32 IntrId2, Xil_InterruptHandler IntrHandler1, Xil_InterruptHandler IntrHandler2){
	u32 Status;

	XScuGic_SetPriorityTriggerType(&IntcInstancePtr, IntrId1, 0xA0, 0x3);
	Status = XScuGic_Connect(&IntcInstancePtr, IntrId1,(Xil_InterruptHandler)IntrHandler1,0);
	if (Status != XST_SUCCESS) {
		xil_printf("XScuGic_Connect Fail..\n\r");
		return Status;
	}
	XScuGic_Enable(&IntcInstancePtr, IntrId1);

	////////////////////////////////////////////////////

	XScuGic_SetPriorityTriggerType(&IntcInstancePtr, IntrId2, 0x98, 0x3);
	Status = XScuGic_Connect(&IntcInstancePtr, IntrId2,(Xil_InterruptHandler)IntrHandler2,0);
	if (Status != XST_SUCCESS) {
		xil_printf("XScuGic_Connect Fail..\n\r");
		return Status;
	}
	XScuGic_Enable(&IntcInstancePtr, IntrId2);
	XScuTimer_EnableInterrupt(timerptr);

	xil_printf("IntrCfg Successful!\r\n");
	return XST_SUCCESS;
}

void SeqDtctIntrHandler (){

	sqrt1=Xil_In32(ADDER_BASEADDERSS+(4*0));
	data_buffer=Xil_In32(ADDER_BASEADDERSS+(4*2));
	printf("data_recvd: %d , square root: %d\n",data_buffer,sqrt1);

	return;
}

void TimerIntrHandler()
{

	ss=(ss+1)%60;
	if(ss==0){
		mm=(mm+1)%60;
	}
	xil_printf("%02d:%02d\r\n",(mm%60),ss%60);
	XScuTimer_ClearInterruptStatus(timerptr);

	return;
}


u32 ScuEnable(){
	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XScuGic_InterruptHandler,(void *)&IntcInstancePtr);
	Xil_ExceptionEnable();

	xil_printf("ScuEnable Successful!\r\n");
	return XST_SUCCESS;
}


int main () 
{
	ScuInit();

	TimerInit();
	IntrCfg(SEQ_DTCT_CUSTOM_IP_INTR_ID, TIMER_INTR_ID, SeqDtctIntrHandler, TimerIntrHandler);
	ScuEnable();
    print("Hello World\n\r");
    print("Successfully Enabled Timer Int and AXI Int");
	XScuTimer_EnableAutoReload(timerptr);
	XScuTimer_LoadTimer(timerptr, TIMER_LOAD_VALUE);
	XScuTimer_Start(timerptr);
	while(1);

	return 0;

}
